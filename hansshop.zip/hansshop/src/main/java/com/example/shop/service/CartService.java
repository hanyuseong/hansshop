// Service Example (CartService.java)
package com.example.shop.service;

import com.example.shop.model.Product;
import com.example.shop.repository.ProductRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class CartService {

    @Autowired
    private ProductRepository productRepository;

    private List<Product> cartItems = new ArrayList<>();

    public List<Product> getCartItems() {
        return cartItems;
    }

    public void addToCart(Long productId) {
        Product product = productRepository.findById(productId).orElse(null);
        if (product != null) {
            cartItems.add(product);
        }
    }

    public void removeFromCart(Long productId) {
        cartItems.removeIf(product -> product.getId().equals(productId));
    }
}